<?php
echo "Hello from test.php 🚀";
?>